#include <iostream>

// include glm
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

void glm_vec_test();
void glm_mat_test();
void glm_transform_test();

std::ostream &operator<< (std::ostream&, const glm::mat4);
std::ostream &operator<< (std::ostream&, const glm::vec3);
std::ostream &operator<< (std::ostream&, const glm::vec4);

int main()
{
  glm_vec_test();
  glm_mat_test();
  glm_transform_test();

  return  0;
}

void glm_vec_test() {
  std::cout << "---------------" << std::endl;
  std::cout << "glm vector test" << std::endl;
  std::cout << "---------------" << std::endl;
  
  glm::vec3 x;
  glm::vec3 y;
  glm::vec3 z;
  float dot;
  
  // TODO 1)
  x.x = 3; x.y = 5; x.z = 7;
  std::cout << "x = " << x << std::endl; 

  // TODO 2)
  y = x;
  std::cout << "y = " << y << std::endl; 

  // TODO 3)
  y += x;
  std::cout << "y += x" << std::endl;
  std::cout << "y => " << y << std::endl;
  std::cout << "x => " << x << std::endl;

  // TODO 4)
  dot = glm::dot(x, y);
  std::cout << "dot(x,y) => " << dot << std::endl;

  // TODO 5)
  x = glm::vec3(1.0f, 0, 0);
  y = glm::vec3(0, 1.0f, 0);
  z = glm::cross(x, y);
  std::cout << "reset x as [1, 0, 0]" << std::endl;
  std::cout << "reset y as [0, 1, 0]" << std::endl;
  std::cout << "z = cross(x, y)" << std::endl;
  std::cout << "z = " << z << std::endl;
}

void glm_mat_test() {
  std::cout << std::endl;
  std::cout << "---------------" << std::endl;
  std::cout << "glm matrix test" << std::endl;
  std::cout << "---------------" << std::endl;

  glm::mat4 A;
  glm::mat4 B;

  // TODO 6) construct identity matrix
  A = glm::mat4(1.0f);
  std::cout << A << std::endl;

  // TODO 7)
  // Notice: The matrix is column major
  A = glm::mat4(glm::vec4(1.0f, 2.0f, 3.0f, 0.0f),
                glm::vec4(2.0f, 1.0f, -2.0f, 0.0f),
                glm::vec4(-1.0f, 0.0f, 1.0f, 0.0f),
                glm::vec4(-1.0f, 2.0f, 4.0f, 1.0f));

  std::cout << "A = " << std::endl;
  std::cout << A << std::endl;  

  // TODO 8)
  B = glm::transpose(A);
  std::cout << "B = A^T" << std::endl;
  std::cout << "B = " << std::endl;
  std::cout << B << std::endl;

  glm::vec4 x(1.0f, 0.0f, 0.0f, 0.0f);
  glm::vec4 y(0.0f, 1.0f, 0.0f, 0.0f);
  glm::vec4 z(0.0f, 0.0f, 1.0f, 0.0f);
  glm::vec4 w(0.0f, 0.0f, 0.0f, 1.0f);

  std::cout << "A*x = " << A * x << std::endl;
  std::cout << "A*y = " << A * y << std::endl;
  std::cout << "A*z = " << A * z << std::endl;
  std::cout << "A*w = " << A * w << std::endl;

  std::cout << "x*A = " << x * A << std::endl;
  std::cout << "y*A = " << y * A << std::endl;
  std::cout << "z*A = " << z * A << std::endl;
  std::cout << "w*A = " << w * A << std::endl;
}

void glm_transform_test() {
  std::cout << std::endl;
  std::cout << "------------------" << std::endl;
  std::cout << "glm transform test" << std::endl;
  std::cout << "------------------" << std::endl;

  glm::mat4 mat_Translate;
  glm::mat4 mat_Scale;
  glm::mat4 mat_Rotate;
  glm::mat4 mat_LookAt;
  glm::mat4 mat_Ortho;
  glm::mat4 mat_Frustum;
  glm::mat4 mat_Perspective;
  
  // TODO 9)
    // 1. translation matrix (1, -1, 2)
  mat_Translate = glm::mat4(1.0f);
  mat_Translate[3][0] = 1.0f;
  mat_Translate[3][1] = -1.0f;
  mat_Translate[3][2] = 2.0f;
    // 2. rotation matrix u = (1, 2, -1), degree = 90 = (pi/2)
  float theta = glm::radians(90.0f);
  glm::vec3 u = glm::normalize(glm::vec3(1.0f, 2.0f, -1.0f));
  mat_Rotate = glm::mat4(1.0f);
  mat_Rotate[0].x = glm::cos(theta) + u.x * u.x * (1 - glm::cos(theta));
  mat_Rotate[0].y = u.y * u.x * (1 - glm::cos(theta)) + u.z * glm::sin(theta);
  mat_Rotate[0].z = u.z * u.x * (1 - glm::cos(theta)) - u.y * glm::sin(theta);

  mat_Rotate[1].x = u.x * u.y * (1 - glm::cos(theta)) - u.z * glm::sin(theta);
  mat_Rotate[1].y = glm::cos(theta) + u.y * u.y * (1 - glm::cos(theta));
  mat_Rotate[1].z = u.z * u.y * (1 - glm::cos(theta)) + u.x * glm::sin(theta);

  mat_Rotate[2].x = u.x * u.z * (1 - glm::cos(theta)) + u.y * glm::sin(theta);
  mat_Rotate[2].y = u.y * u.z * (1 - glm::cos(theta)) - u.x * glm::sin(theta);
  mat_Rotate[2].z = glm::cos(theta) + u.z * u.z * (1 - glm::cos(theta));

    // 3. scaling matrix by x = 2, y = 1, z = 1.5
  mat_Scale = glm::mat4(1.0f);
  mat_Scale[0].x *= 2.0f;
  mat_Scale[1].y *= 1.0f;
  mat_Scale[2].z *= 1.5f;

    // 4. camPos = (0, 0, -5) camUpVec = (0, 1, 0) lookTarget = (0, 0, 0);
  mat_LookAt = glm::lookAt(glm::vec3(0.0f, 0.0f, -5.0f),
                          glm::vec3(0.0f, 0.0f, 0.0f),
                          glm::vec3(0.0f, 1.0f, 0.0f));
    
    // 5. orthographic projection matrix l = 1, r = -1, b = 1, t = -1, near = 1, far = -1
  float l = 1.0f, r = -1.0f, b = 1.0f, t = -1.0f, near = 1.0f, far = -1.0f;
  mat_Ortho = glm::ortho(l, r, b, t, near, far);
  // mat_Ortho = glm::mat4(1.0f);
  // mat_Orth[0].x = 2 / (r - l);
  // mat_Orth[1].y = 2 / (t - b);
  // mat_Orth[2].z = -1 * 2 / (far - near);

  // mat_Orth[3].x = -1 * (r + l) / (r - 1);
  // mat_Orth[3].y = -1 * (t + b) / (t - b);
  // mat_Orth[3].z = -1 * (far + near) / (far - near);

    // 6. frustrum matrix l = -0.1, r = 0.1, b = -0.1, t = 0.1, near = 0.1, far = 1000;
  l = -0.1, r = 0.1, b = -0.1, t = 0.1, near = 0.1, far = 1000.0f;
  mat_Frustum = glm::frustum(l, r, b, t, near, far);

    // 7. perspective matrix fovy = 60, near = 0.001, far = 10000, aspect = 1.0
  float fovy = glm::radians(60.0f), aspect = 1.0f; near = 0.001f, far = 10000.0f;
  mat_Perspective = glm::perspective(fovy, aspect, near, far);


  // DO NOT EDIT below this line
  std::cout << "Translation matrix" << std::endl;
  std::cout << mat_Translate << std::endl;

  std::cout << "Rotation matrix" << std::endl;
  std::cout << mat_Rotate << std::endl;

  std::cout << "Scaling matrix" << std::endl;
  std::cout << mat_Scale << std::endl;

  std::cout << "View matrix with lookAt()" << std::endl;
  std::cout << mat_LookAt << std::endl;

  std::cout << "Projection matrix with ortho()" << std::endl;
  std::cout << mat_Ortho << std::endl;

  std::cout << "Projection matrix with frusutm()" << std::endl;
  std::cout << mat_Frustum << std::endl;

  std::cout << "Projection matrix with perspective()" << std::endl;
  std::cout << mat_Perspective << std::endl;

}

// DO NOT EDIT below this line
std::ostream &operator<< (std::ostream &os, const glm::vec3 v) {
  os << "[";
  os << v.x << ", " << v.y << ", " << v.z;
  os << "]";
  
  return os;
}
std::ostream &operator<< (std::ostream &os, const glm::vec4 v) {
  os << "[";
  os << v.x << ", " << v.y << ", " << v.z << ", " << v.w;
  os << "]";
  
  return os;
}
std::ostream &operator<< (std::ostream &os, const glm::mat4 m) {
  os << "[" << m[0][0] << ", " << m[1][0] << ", " << m[2][0] << ", " << m[3][0] << "]" << std::endl;
  os << "[" << m[0][1] << ", " << m[1][1] << ", " << m[2][1] << ", " << m[3][1] << "]" << std::endl;
  os << "[" << m[0][2] << ", " << m[1][2] << ", " << m[2][2] << ", " << m[3][2] << "]" << std::endl;
  os << "[" << m[0][3] << ", " << m[1][3] << ", " << m[2][3] << ", " << m[3][3] << "]" << std::endl;
  
  return os;
}
