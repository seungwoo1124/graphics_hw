glm_vec_test(), glm_mat_test(), glm_transform_test() 함수의 [//TODO](//todo) 부분을 수정하여 프로그램을 완성하시오.

- 함께 첨부한 PDF를 참고할 것
- 중요 : DO NOT EDIT below this line 부분은 절대 수정하지 마세요.

완성된 프로그램을 실행했을 경우, 그 출력은 output.txt와 동일해야 합니다.